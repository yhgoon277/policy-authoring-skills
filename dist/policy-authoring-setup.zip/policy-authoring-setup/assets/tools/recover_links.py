#!/usr/bin/env python3
"""recover_links — 원천 HTML(진실원천)에서 PG↔PI 링크를 복원한다 (R3 충실).

NC 변환·간소화 과정에서 정책그룹↔정책항목 연결(policy_groups[].items[].id / policy_details
[].policy_id)이 비어버리는 경우가 있다(게이트 GROUP_DETAIL_UNLINKED·렌더 PG 누락의 원인).
원천 HTML의 '정책 상세' 섹션에는 각 PG에 속한 PI가 그대로 남아있으므로(`source_html_index`),
거기서 매핑을 떠서 **빈 링크만 채운다**(기존 비어있지 않은 값은 보존 — 발명/임의변경 금지, R3).

R5 도메인코드 현행화가 적용된 spec(새 코드)에는 target_code를 줘서 원천(옛 코드) PI/PG id를
relabel한 뒤 매칭한다.
"""
import copy
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import source_html_index as shi  # noqa: E402


def recover_pg_pi_links(spec, source_html, target_code=None):
    """원천 HTML의 PG→PI로 spec의 빈 PG↔PI 링크를 복원. 원본 spec은 변형하지 않음."""
    idx = shi.build_index(source_html)
    pg_to_pis = idx["pg_to_pis"]
    if target_code:
        import domain_code_normalize as dcn
        pg_to_pis = {dcn.relabel_to(pg, target_code): [dcn.relabel_to(p, target_code) for p in pis]
                     for pg, pis in pg_to_pis.items()}

    out = copy.deepcopy(spec)
    pi_to_pg = {pi: pg for pg, pis in pg_to_pis.items() for pi in pis}
    pi_by_id = {p["id"]: p for p in out.get("policy_details", []) or []}

    # 1) policy_details: policy_id/group_id 빈 곳을 원천 PG로 채움
    for p in out.get("policy_details", []) or []:
        pg = pi_to_pg.get(p.get("id"))
        if not pg:
            continue
        if not (p.get("policy_id") or "").strip():
            p["policy_id"] = pg
        if not (p.get("group_id") or "").strip():
            p["group_id"] = pg

    # 2) policy_groups: items 비어있으면 원천 PI 목록으로 채움(순서 보존)
    pg_by_id = {g.get("id"): g for g in out.get("policy_groups", []) or []}
    for pg, pis in pg_to_pis.items():
        g = pg_by_id.get(pg)
        if not g:
            continue
        existing = [it for it in (g.get("items") or []) if it.get("id")]
        if not existing:
            g["items"] = [{"id": pi, "name": (pi_by_id.get(pi) or {}).get("name", "")} for pi in pis]
    return out


if __name__ == "__main__":
    import argparse
    import json
    ap = argparse.ArgumentParser()
    ap.add_argument("spec_json")
    ap.add_argument("source_html")
    ap.add_argument("--target-code", default=None)
    ap.add_argument("--out", default=None)
    a = ap.parse_args()
    spec = json.load(open(a.spec_json, encoding="utf-8"))
    out = recover_pg_pi_links(spec, a.source_html, a.target_code)
    linked = sum(1 for g in out.get("policy_groups", []) if any(it.get("id") for it in (g.get("items") or [])))
    print(f"  [recover_links] PG link 채움 → {linked}/{len(out.get('policy_groups', []))} 그룹 연결")
    if a.out:
        json.dump(out, open(a.out, "w", encoding="utf-8"), ensure_ascii=False, indent=2)
        print(f"  saved: {a.out}")
